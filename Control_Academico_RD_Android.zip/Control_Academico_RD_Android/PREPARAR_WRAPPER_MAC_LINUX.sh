#!/usr/bin/env sh
set -eu
mkdir -p gradle/wrapper
curl -L "https://raw.githubusercontent.com/gradle/gradle/v8.13.0/gradle/wrapper/gradle-wrapper.jar" -o gradle/wrapper/gradle-wrapper.jar
echo "Gradle Wrapper preparado correctamente."
