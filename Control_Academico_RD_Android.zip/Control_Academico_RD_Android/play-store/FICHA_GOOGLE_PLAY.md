# Borrador de ficha para Google Play

## Nombre
Control Académico RD PRO MAX

## Descripción corta
Control docente: estudiantes, asistencia, calificaciones, evidencias y reportes.

## Descripción larga
Control Académico RD PRO MAX es una herramienta de apoyo para docentes que permite organizar estudiantes, asistencia, calificaciones por competencias, recuperación pedagógica, evidencias de aprendizaje, incidencias, reportes y recursos para la práctica docente.

Incluye funciones para los niveles Inicial, Primaria, Secundaria y Técnico Profesional, además de herramientas para planificaciones, instrumentos de evaluación, presentaciones y actividades educativas.

La aplicación funciona como registro auxiliar y herramienta de organización docente. No es una aplicación oficial ni está certificada o respaldada por el Ministerio de Educación de la República Dominicana.

## Categoría sugerida
Educación

## Modelo inicial sugerido
Aplicación pagada con compra única en Google Play.

## Pendientes gráficos
- Icono de Google Play: 512 × 512 px
- Gráfico de funciones: 1024 × 500 px
- Capturas de pantalla de teléfono
