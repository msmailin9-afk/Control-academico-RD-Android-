# Política de Privacidad — BORRADOR

> Este documento es un borrador inicial y debe revisarse antes de publicarse como política legal definitiva.

## Control Académico RD PRO MAX

Control Académico RD PRO MAX es una herramienta auxiliar para la gestión docente. Puede almacenar información introducida por el usuario relacionada con estudiantes, asistencia, calificaciones, evidencias, incidencias y otros datos académicos.

### Datos tratados
Según las funciones utilizadas, el usuario puede introducir nombres de estudiantes, matrícula o identificador, información académica, asistencia, observaciones, datos de responsables, información de salud o apoyo educativo, fotografías y documentos.

### Finalidad
Los datos se utilizan exclusivamente para ofrecer las funciones de organización, seguimiento y elaboración de reportes solicitadas por el usuario dentro de la aplicación.

### Almacenamiento y sincronización
La aplicación puede conservar información localmente en el dispositivo y, cuando el usuario inicia sesión y utiliza la sincronización, en la infraestructura configurada con Supabase.

### Responsabilidad del usuario
El docente o institución que utilice la aplicación debe contar con autorización y base legítima para registrar información personal, especialmente cuando corresponda a menores de edad o a datos sensibles.

### Eliminación
El usuario puede eliminar información desde las funciones disponibles en la aplicación. Se debe definir antes del lanzamiento un mecanismo público para solicitar eliminación de cuenta y datos asociados.

### Contacto
Correo de soporte: [AGREGAR CORREO DE SOPORTE]

Fecha de vigencia: [AGREGAR FECHA]
