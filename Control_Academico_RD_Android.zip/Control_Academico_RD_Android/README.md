# Control Académico RD PRO MAX — Android

Proyecto Android de **Control Académico RD PRO MAX**, preparado para abrirse en Android Studio y generar un Android App Bundle (`.aab`) para Google Play.

## Identidad de la app
- Nombre: Control Académico RD PRO MAX
- Package/Application ID: `com.smailindigital.controlacademicord`
- Version Code: `1`
- Version Name: `1.0.0`
- minSdk: 24 (Android 7.0)
- targetSdk / compileSdk: 36

## Qué conserva
- El `index.html` completo está integrado dentro de la app.
- Supabase continúa funcionando por Internet.
- JavaScript y almacenamiento web local habilitados.
- Selección de archivos/fotos desde Android.
- Impresión mediante el servicio de impresión de Android.
- Exportación de respaldo JSON mediante el selector nativo “Guardar como”.
- Enlaces externos se abren en el navegador del dispositivo.

## Abrir y generar AAB
1. Instala una versión reciente de Android Studio.
2. Abre la carpeta completa `Control_Academico_RD_Android`.
3. Si Android Studio indica que falta el Wrapper, ejecuta `PREPARAR_WRAPPER_WINDOWS.bat` (Windows) o `./PREPARAR_WRAPPER_MAC_LINUX.sh` (Mac/Linux), y vuelve a sincronizar.
4. Espera a que Gradle sincronice y descargue dependencias.
5. Instala Android SDK 36 si Android Studio lo solicita.
6. Prueba la app en un teléfono o emulador.
7. Para publicar: **Build > Generate Signed App Bundle or APK > Android App Bundle**.
8. Crea una clave de firma (`.jks`) y guárdala en un lugar seguro. Nunca la subas a GitHub.

También se incluye un workflow de GitHub Actions (`.github/workflows/android-build.yml`) que puede generar automáticamente un APK de prueba y un AAB sin firma. La firma de publicación se configura después con secretos seguros.

## Antes de Google Play
- Configurar URL pública de Política de Privacidad.
- Completar “Seguridad de los datos / Data safety”.
- Revisar el tratamiento de datos de menores y datos sensibles de estudiantes.
- Crear icono de tienda 512×512, banner y capturas de pantalla.
- Probar creación de cuenta, inicio de sesión, sincronización, impresión, importación y exportación.

## Importante
Este producto es un registro auxiliar docente orientado al contexto dominicano. No debe presentarse como una aplicación oficial ni certificada por MINERD.
