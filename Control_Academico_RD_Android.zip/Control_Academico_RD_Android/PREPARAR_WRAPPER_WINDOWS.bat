@echo off
setlocal
if not exist gradle\wrapper mkdir gradle\wrapper
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/gradle/gradle/v8.13.0/gradle/wrapper/gradle-wrapper.jar' -OutFile 'gradle/wrapper/gradle-wrapper.jar'"
if errorlevel 1 (
  echo No se pudo descargar gradle-wrapper.jar.
  pause
  exit /b 1
)
echo Gradle Wrapper preparado correctamente.
pause
